import java.io.File;
import java.io.IOException;

public class App {

    public static void main(String[] args) {

        File mainDir = new File("main");
        File customerDir = new File("main/CustomerDir");

        File customerFile = new File("main/customer.txt");
        File save = new File("main/Save.txt");

        if (!mainDir.exists())
            mainDir.mkdirs();
        if (!customerDir.exists())
            customerDir.mkdirs();

        if (!save.exists()) {
            try {
                save.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(!customerFile.exists()) {
            try {
                customerFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Home Home = new Home();

    }

}