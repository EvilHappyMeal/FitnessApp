import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Home extends JFrame implements Runnable, ActionListener {

    //Strings
    String appTitel;


    //ints


    //booleans


    //Arrays
    ArrayList<String> customerList = new ArrayList<>();
    ArrayList<String> customerDetailsList = new ArrayList<>();

    //Colors
    Color color1 = new Color(200, 200, 200);
    Color colorClicked = new Color(160, 160, 160);
    Color colorBackground = new Color(50, 50, 50);

    //Fonts
    Font myFont = new Font("Arial", Font.BOLD, 20);

    //Borders
    Border border = BorderFactory.createLineBorder(Color.RED, 2);
    Border border1 = BorderFactory.createLineBorder(Color.DARK_GRAY, 2);

    //Buttons
    JButton customers = new JButton();
    JButton events = new JButton();
    JButton employees = new JButton();
    JButton news = new JButton();
    JButton newCustomer = new JButton();
    JButton searchCustomer = new JButton();
    JButton trainingPlan = new JButton();

    //Labels
    JLabel date = new JLabel();
    JLabel date2 = new JLabel();
    JLabel customerName = new JLabel();
    JLabel customerAdress = new JLabel();
    JLabel customerBank = new JLabel();
    JLabel customerStatus = new JLabel();
    JLabel customerTrainingplan = new JLabel();

    //Panels
    JPanel customerPanel = new JPanel();
    JPanel eventsPanel = new JPanel();
    JPanel employeePanel = new JPanel();
    JPanel newsPanel = new JPanel();
    JPanel customerDetails = new JPanel();


    //Tables

    //Lists
    JList customerJList = new JList(customerList.toArray(new String[customerList.size()]));

    //Files
    File customerFile = new File("main/customer.txt");

    Home() {

        //Panels

        //Customers
        customerPanel.setBounds(251, 98, 1000, 570);
        customerPanel.setVisible(false);
        customerPanel.setBackground(color1);
        customerPanel.setFont(myFont);
        customerPanel.setBorder(border);
        customerPanel.setLayout(null);

        //CustomerDetails
        customerDetails.setBounds(252,48,748,522);
        customerDetails.setVisible(true);
        customerDetails.setBackground(Color.GREEN);
        customerDetails.setFont(myFont);
        customerDetails.setBorder(border);
        customerDetails.setLayout(null);


        //events
        eventsPanel.setBounds(251, 98, 1000, 570);
        eventsPanel.setVisible(false);
//        eventsPanel.setBackground(color1);
        eventsPanel.setFont(myFont);
        eventsPanel.setBorder(border);
        eventsPanel.setBackground(new Color(120, 60, 120));
        eventsPanel.setLayout(null);

        //employee
        employeePanel.setBounds(251, 98, 1000, 570);
        employeePanel.setVisible(false);
//        employeePanel.setBackground(color1);
        employeePanel.setFont(myFont);
        employeePanel.setBorder(border);
        employeePanel.setBackground(new Color(120, 60, 20));
        employeePanel.setLayout(null);

        //news
        newsPanel.setBounds(251, 98, 1000, 570);
        newsPanel.setVisible(false);
//        newsPanel.setBackground(color1);
        newsPanel.setFont(myFont);
        newsPanel.setBorder(border);
        newsPanel.setBackground(new Color(20, 60, 120));
        newsPanel.setLayout(null);


        //Textfields


        //Tables & Lists

        //Customer
        customerJList.setBounds(0,48,252,522);
        customerJList.setVisible(true);
        customerJList.setBorder(border);
        customerJList.setVisibleRowCount(10);
        customerJList.addListSelectionListener(new ListenHandler());

        //Labels

        //Date
        date.setBounds(2, 2, 250, 50);
        date.setVisible(true);
        date.setBackground(color1);
        date.setFocusable(false);
        date.setFont(myFont);
        date.setBorder(border);
        date.setOpaque(true);
        date.setHorizontalAlignment(SwingConstants.CENTER);
        date2.setBounds(2, 50, 250, 50);
        date2.setVisible(true);
        date2.setBackground(color1);
        date2.setFocusable(false);
        date2.setFont(myFont);
        date2.setBorder(border);
        date2.setOpaque(true);
        date2.setHorizontalAlignment(SwingConstants.CENTER);
        Thread t1 = new Thread(this);
        t1.start();

        //Customer Name
        customerName.setVisible(true);
        customerName.setFocusable(false);
        customerName.setFont(myFont);
        customerName.setOpaque(true);
        customerName.setHorizontalAlignment(SwingConstants.CENTER);
        customerName.setBounds(224,50,250,50);
        customerName.setBackground(Color.RED);

        //customer Address
        customerAdress.setVisible(true);
        customerAdress.setFocusable(false);
        customerAdress.setFont(myFont);
        customerAdress.setOpaque(true);
        customerAdress.setHorizontalAlignment(SwingConstants.CENTER);
        customerAdress.setBounds(10,100,300,50);
        customerAdress.setBorder(border1);

        //customer Banking Details
        customerBank.setVisible(true);
        customerBank.setFocusable(false);
        customerBank.setFont(myFont);
        customerBank.setOpaque(true);
        customerBank.setHorizontalAlignment(SwingConstants.CENTER);

        //customer member status
        customerStatus.setVisible(true);
        customerStatus.setFocusable(false);
        customerStatus.setFont(myFont);
        customerStatus.setOpaque(true);
        customerStatus.setHorizontalAlignment(SwingConstants.CENTER);

        //customer trainingplan
        customerTrainingplan.setVisible(true);
        customerTrainingplan.setFont(myFont);
        customerTrainingplan.setFocusable(false);
        customerTrainingplan.setOpaque(true);
        customerTrainingplan.setHorizontalAlignment(SwingConstants.CENTER);


        //Buttons

        //Customers
        customers.setText("Kunden");
        customers.setVisible(true);
        customers.setBounds(2, 98, 250, 50);
        customers.setFocusable(false);
        customers.setFont(myFont);
        customers.setBackground(color1);
        customers.setBorder(border);
        customers.addActionListener(this);

        //events
        events.setText("Termine");
        events.setVisible(true);
        events.setBounds(2, 146, 250, 50);
        events.setFocusable(false);
        events.setFont(myFont);
        events.setBackground(color1);
        events.setBorder(border);
        events.addActionListener(this);

        //employees
        employees.setText("Mitarbeiter");
        employees.setVisible(true);
        employees.setBounds(2, 194, 250, 50);
        employees.setFocusable(false);
        employees.setFont(myFont);
        employees.setBackground(color1);
        employees.setBorder(border);
        employees.addActionListener(this);

        //news
        news.setText("News");
        news.setVisible(true);
        news.setBounds(2, 242, 250, 50);
        news.setFocusable(false);
        news.setFont(myFont);
        news.setBackground(color1);
        news.setBorder(border);
        news.addActionListener(this);

        //searchCustomer
        searchCustomer.setText("Kunde suchen");
        searchCustomer.setVisible(true);
        searchCustomer.setBounds(2, 2, 250, 46);
        searchCustomer.setFocusable(false);
        searchCustomer.setFont(myFont);
        searchCustomer.setBackground(color1);
        searchCustomer.setBorder(border1);
        searchCustomer.addActionListener(this);

        //newCustomer
        newCustomer.setText("Kunde hinzufügen");
        newCustomer.setVisible(true);
        newCustomer.setBounds(250, 2, 250, 46);
        newCustomer.setFocusable(false);
        newCustomer.setFont(myFont);
        newCustomer.setBackground(color1);
        newCustomer.setBorder(border1);
        newCustomer.addActionListener(this);

        //trainingPlan
        trainingPlan.setVisible(false);
        trainingPlan.setBackground(color1);
        trainingPlan.setText("Trainingsplan verwalten");
        trainingPlan.setBounds(498,2,250,46);
        trainingPlan.setFocusable(false);
        trainingPlan.setFont(myFont);
        trainingPlan.setBorder(border1);
        trainingPlan.addActionListener(this);


        //Frame
        appTitel = titel()[0];
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setVisible(true);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setTitle(appTitel);
        this.setResizable(false);
        this.getContentPane().setBackground(colorBackground);

        //Add
        this.add(customers);
        this.add(date);
        this.add(date2);
        this.add(events);
        this.add(employees);
        this.add(news);
        this.add(customerPanel);
        this.add(newsPanel);
        this.add(eventsPanel);
        this.add(employeePanel);

        customerPanel.add(searchCustomer);
        customerPanel.add(newCustomer);
        customerPanel.add(customerJList);
        customerPanel.add(trainingPlan);
        customerPanel.add(customerDetails);

        customerDetails.add(customerName);
        customerDetails.add(customerAdress);
        customerDetails.add(customerBank);
        customerDetails.add(customerStatus);
        customerDetails.add(customerTrainingplan);

    }

    private void readCustomerFile() {

        if (customerFile.exists()) {

            try {
                Scanner sc = new Scanner(customerFile);

                while (sc.hasNext()) {
                    if(customerList.size() - 1 > 0) {
                        if (!customerList.get(customerList.size() - 1).equals(sc.nextLine()))
                            customerList.add(sc.nextLine());
                        else
                            break;
                    }else
                        customerList.add(sc.nextLine());

                }
            } catch (FileNotFoundException fileNotFoundException) {
                fileNotFoundException.printStackTrace();
            }
        }

        Collections.sort(customerList);
        customerJList.setListData(customerList.toArray(new String [customerList.size()]));

    }

    public static String[] titel() {

        File save = new File("main/Save.txt");

        String[] saveString = {"", "", "", "", ""};
        String appTitel;

        if (save.exists()) {
            Scanner sc;
            try {
                sc = new Scanner(save);

                int zaehler = 0;

                while (sc.hasNext()) {

                    saveString[zaehler] = sc.next();
                    zaehler++;

                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        if (saveString[0].equals(null) || saveString[0].equals("")) {
            appTitel = JOptionPane.showInputDialog(
                    null,
                    "Wie heißt dein Gym?",
                    null,
                    JOptionPane.PLAIN_MESSAGE);
            saveString[0] = appTitel;

            try {
                OutputStream stream = new FileOutputStream(save);
                stream.write(appTitel.getBytes());
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return saveString;

    }      //Declare gym-name


    public void run() {

        while (true) {

            Calendar calendar = Calendar.getInstance();

            SimpleDateFormat sDateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy");
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm:ss");
            Date date1 = calendar.getTime();
            Date date3 = calendar.getTime();
            String timeString = sDateFormat.format(date1);
            String timeString2 = simpleDateFormat2.format(date3);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            date.setText(timeString);
            date2.setText(timeString2);

        }

    }                   //Date


    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == customers) {


            customers.setBackground(colorClicked);

            readCustomerFile();

            customerPanel.setVisible(true);

            events.setBackground(color1);
            employees.setBackground(color1);
            news.setBackground(color1);

            eventsPanel.setVisible(false);
            employeePanel.setVisible(false);
            newsPanel.setVisible(false);

        }


        if (e.getSource() == events) {

            events.setBackground(colorClicked);

            eventsPanel.setVisible(true);

            customers.setBackground(color1);
            employees.setBackground(color1);
            news.setBackground(color1);

            customerPanel.setVisible(false);
            employeePanel.setVisible(false);
            newsPanel.setVisible(false);

        }

        if (e.getSource() == employees) {

            employees.setBackground(colorClicked);

            employeePanel.setVisible(true);

            customers.setBackground(color1);
            news.setBackground(color1);
            events.setBackground(color1);

            customerPanel.setVisible(false);
            newsPanel.setVisible(false);
            eventsPanel.setVisible(false);

        }

        if (e.getSource() == news) {

            news.setBackground(colorClicked);

            newsPanel.setVisible(true);

            customers.setBackground(color1);
            events.setBackground(color1);
            employees.setBackground(color1);

            customerPanel.setVisible(false);
            eventsPanel.setVisible(false);
            employeePanel.setVisible(false);

        }


    }

    private class ListenHandler implements ListSelectionListener{

        @Override
        public void valueChanged(ListSelectionEvent e) {

            if(e.getValueIsAdjusting()) {

                customerList();

                customerName.setText(customerDetailsList.get(0));
                customerName.updateUI();
                customerAdress.setText("<html><body>" + customerDetailsList.get(1) + "<br>" + customerDetailsList.get(2) + "</body></html>");
                customerAdress.updateUI();

            }

        }
    }

    private void customerList (){

        int index;
        String customer;

        index = customerJList.getSelectedIndex();

        customer = customerList.get(index);

        File customerDir = new File ("main/CustomerDir");

            for (File f : Objects.requireNonNull(customerDir.listFiles())) {

                if (f.getName().contains(customer)) {

                    trainingPlan.setVisible(true);

                    try {
                        Scanner sc = new Scanner(f);
                        while (sc.hasNextLine()) {
                            customerDetailsList.add(sc.nextLine());
                        }
                    } catch (FileNotFoundException fileNotFoundException) {
                        fileNotFoundException.printStackTrace();
                    }

                }
            }

    }

}